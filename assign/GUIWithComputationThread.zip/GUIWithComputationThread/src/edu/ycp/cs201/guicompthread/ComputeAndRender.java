package edu.ycp.cs201.guicompthread;

import java.awt.image.BufferedImage;

import javax.swing.SwingUtilities;

public class ComputeAndRender implements Runnable {
	private View view;
	private Region region;
	
	public ComputeAndRender(View view, Region region) {
		this.view = view;
		this.region = region;
	}

	@Override
	public void run() {
		// Do the computation and render the result
		Compute comp = new Compute(region);
		comp.execute();
		Model model = comp.getModel();
		Renderer renderer = new Renderer(model);
		renderer.render();
		
		final BufferedImage img = renderer.getImg();
		
		// Update the view's BufferedImage.
		
		// IMPORTANT: this must be done in the GUI thread.
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				view.computationFinished(img);
			}
		});
	}

}

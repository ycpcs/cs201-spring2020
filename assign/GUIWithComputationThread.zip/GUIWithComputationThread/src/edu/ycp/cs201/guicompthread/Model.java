package edu.ycp.cs201.guicompthread;

public class Model {
	public static final int WIDTH = 600;
	public static final int HEIGHT = 600;
	
	private int[][] data;
	
	public Model() {
		data = new int[HEIGHT][WIDTH];
	}
	
	public int[][] getData() {
		return data;
	}
}

package edu.ycp.cs201.nchoosek;

public class Memoization implements ComputeBinomialCoefficient {

	public int compute(int n, int k) {
		// TODO: implement
		throw new UnsupportedOperationException("not implemented yet!");
	}

	public String toString() {
		return "Memoization";
	}
}

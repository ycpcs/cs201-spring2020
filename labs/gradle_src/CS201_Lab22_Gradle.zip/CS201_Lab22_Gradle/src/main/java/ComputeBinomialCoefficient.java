public interface ComputeBinomialCoefficient {
	public int compute(int n, int k);
}

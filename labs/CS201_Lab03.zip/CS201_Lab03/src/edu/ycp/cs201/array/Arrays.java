package edu.ycp.cs201.array;

import java.util.Scanner;

public class Arrays {
	/**
	 * Using the given Scanner object,
	 * read in the given number of integer values
	 * and return them in an array.
	 * 
	 * @param keyboard    the Scanner object to use
	 * @param numElements the number of integer values to read
	 * @return an array containing the integer values read from the keyboard
	 */
	public static int[] readArray(Scanner keyboard, int numElements) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Print out the values of all of the elements in the
	 * given array.
	 * 
	 * @param arr an array
	 */
	public static void printArray(int[] arr) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Reverse the elements of the given array.
	 * 
	 * @param arr an array
	 */
	public static void reverseArray(int[] arr) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		int[] arr;
		
		int numElements;
		
		System.out.println("How many values? ");
		numElements = keyboard.nextInt();
		
		System.out.println("Please enter " + numElements + " values:");
		arr = readArray(keyboard, numElements);
		
		System.out.println("You entered the following values:");
		printArray(arr);
		

		System.out.println("Now I am going to reverse the array for you...");
		reverseArray(arr);
		
		System.out.println("Here are the reversed array values:");
		printArray(arr);
	}
}
